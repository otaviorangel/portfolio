# Portfólio — Otávio Rangel

Site de apresentação pessoal e escolar desenvolvido em HTML, CSS e JavaScript.

## Como visualizar

Abra o arquivo `index.html` em um navegador.

## Publicação no GitHub Pages

Este projeto pode ser publicado pelo GitHub Pages usando a branch `main` e a pasta raiz (`/`). O arquivo inicial do site é `index.html`.
